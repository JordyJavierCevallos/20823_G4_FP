#include <stdio.h>
#include "divfact.h"

int main() {
    float a = 10.0, b = 2.0;
    int n = 12;

    printf("División: %.2f\n", dividir(a, b));
    printf("Factores de %d: ", n);
    factorizar(n);

    return 0;
}
