#ifndef DIVFACT_H
#define DIVFACT_H

float dividir(float a, float b);
void factorizar(int n);

#endif
