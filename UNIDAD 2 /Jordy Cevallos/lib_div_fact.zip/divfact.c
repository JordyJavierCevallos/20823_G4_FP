#include <stdio.h>
#include "divfact.h"

float dividir(float a, float b) {
    if (b == 0.0f) return 0.0f;
    return a / b;
}

void factorizar(int n) {
    for (int i = 1; i <= n; i++) {
        if (n % i == 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
}
