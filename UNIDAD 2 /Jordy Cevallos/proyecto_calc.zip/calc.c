#include "calc.h"

float sumar(float x, float y) {
    return x + y;
}

float restar(float x, float y) {
    return x - y;
}

float multiplicar(float x, float y) {
    return x * y;
}

float dividir(float x, float y) {
    if (y == 0.0f) return 0.0f;
    return x / y;
}
