#ifndef CALC_H
#define CALC_H

float sumar(float x, float y);
float restar(float x, float y);
float multiplicar(float x, float y);
float dividir(float x, float y);

#endif
