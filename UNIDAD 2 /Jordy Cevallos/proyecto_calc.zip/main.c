#include <stdio.h>
#include "calc.h"

int main() {
    float a = 8.0, b = 2.0;

    printf("Suma: %.2f\n", sumar(a, b));
    printf("Resta: %.2f\n", restar(a, b));
    printf("Multiplicación: %.2f\n", multiplicar(a, b));
    printf("División: %.2f\n", dividir(a, b));

    return 0;
}
