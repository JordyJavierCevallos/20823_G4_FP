#ifndef MIMATH_H
#define MIMATH_H

float suma(float a, float b);
float resta(float a, float b);
float multiplicacion(float a, float b);
float division(float a, float b);

#endif
